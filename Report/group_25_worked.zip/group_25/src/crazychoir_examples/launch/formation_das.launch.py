import os
import numpy as np
import pathlib

from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

from webots_ros2_driver.webots_launcher import WebotsLauncher

node_frequency = 100 # [Hz]

MAXITERS = 5000
N = 4
dd = 3 # State dimension
pos_init = (np.random.rand(N, 3) - 0.5) *0.1
pos_init[:, 2] = 0.
comm_time = 1/30 # Comunication time
euler_step = 0.005 # Integration step
L = 2

move = 3   # Raggio del cerchio



# Moving leaders
agent_types = np.zeros((N)) # Followers -> 0
for i in range(N):
    if i%2 == 1:
        agent_types[i] = 1 # Leaders -> 1

if N == 4: # Square
    D = np.sqrt(2)*L
    distances = [
                [0, L, D, L],
                [L, 0, L, D],
                [D, L, 0, L],
                [L, D, L, 0]
                ]
    
in_neighs = np.nonzero(distances)[0].tolist()
out_neighs = np.nonzero(distances)[0].tolist()

package_dir = get_package_share_directory('crazychoir_examples')

def get_cf_driver(agent_id):
    robot_description = pathlib.Path(os.path.join(package_dir, 'crazyflie_fpqr.urdf')).read_text()

    crazyflie_driver = Node(
        package='webots_ros2_driver',
        executable='driver',
        namespace='agent_{}'.format(agent_id),
        output='screen',
        additional_env={
            'WEBOTS_ROBOT_NAME':'agent_{}'.format(agent_id),
            },
        parameters=[
            {'robot_description': robot_description},
        ]
    )

    return crazyflie_driver

def generate_launch_description():


    # generate initial positions to evaluate initial takeoff
    P = np.zeros((N, 3))   
    P[0]  = np.array([ 1,  1,  3])
    P[1]  = np.array([1.5, 0.7,  3])
    P[2]  = np.array([ 0.7,  0.3,  3])
    P[3]  = np.array([ 0.3, 0.6,  3])

    # initialize launch description
    launch_description = []

    # Launch control Panel
    launch_description.append(Node(
                package='crazychoir_examples', 
                executable='crazychoir_formation_webots_gui',
                output='screen',
                parameters=[{
                    'n_agents': N,
                    }]))

            
    webots = WebotsLauncher(world=os.path.join(package_dir, 'worlds', 'formation_world.wbt'))

    launch_description.append(webots)

    # add executables for each robot
    for i in range(N):

        # webots exec
        launch_description.append(get_cf_driver(i))
        launch_description.append(Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            additional_env={'WEBOTS_ROBOT_NAME':'agent_{}'.format(i)},
            namespace='agent_{}'.format(i),
            output='screen',
            parameters=[{
                'robot_description': '<robot name=""><link name=""/></robot>',
                }]))

        # guidance
        launch_description.append(Node(
            package='crazychoir_examples',
            executable='crazychoir_formation_webots_guidance', 
            output='screen',
            namespace='agent_{}'.format(i),
            parameters=[{
                'freq': node_frequency, 
                'agent_id': i, 
                'N': N, 
                'dd': dd, 
                'in_neigh': in_neighs, 
                'out_neigh': out_neighs, 
                'pos_init': pos_init[i].tolist(),
                }]))

        # controller
        launch_description.append(Node(
            package='crazychoir_examples', 
            executable='crazychoir_formation_webots_controller', 
            namespace='agent_{}'.format(i),
            output='screen',
            parameters=[{
                'freq': node_frequency,                       
                'agent_id': i,
                }]))

    return LaunchDescription(launch_description)
