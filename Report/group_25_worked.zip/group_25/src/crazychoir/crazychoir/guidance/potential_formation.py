from typing import Callable
import numpy as np
from geometry_msgs.msg import Vector3
from std_msgs.msg import Empty
from trajectory_msgs.msg import JointTrajectory as Trajectory, JointTrajectoryPoint as TrajectoryPoint

from .distributed_control import DistributedControl
import time

class PotentialFormation(DistributedControl):
    """
    Formation Control 

    Implements a bearing-based formation control law for second order systems.
    """
    def __init__(self, update_frequency: float,
                 pose_handler: str=None, pose_topic: str=None, pose_callback: Callable=None, input_topic = 'acceleration'):
        super().__init__(update_frequency, pose_handler, pose_topic, pose_callback, input_topic)

        self.get_logger().info('Guidance {} started'.format(self.agent_id))

        self.frequency = self.get_parameter('freq').value
        self.id = self.get_parameter('agent_id').value
        self.N = self.get_parameter('N').value
        self.dd = self.get_parameter('dd').value
        self.pos = np.array(self.get_parameter('pos_init').value)
             
        # Subscription to gui commands
        self.take_off_trigger_subscription = self.create_subscription(Empty, '/takeoff', self.start_take_off, 10)
        self.land_trigger_subscription = self.create_subscription(Empty, '/land', self.start_land, 10)
        self.experiment_trigger_subscription = self.create_subscription(Empty, '/experiment_trigger', self.start_experiment, 10)

        # Subscription to trajectory topic
        self.publishers_traj_params = self.create_publisher(Trajectory, 'traj_params', 1)

        # FSM Variables
        self.height = 1.0
        self.formation = False
        self.takeoff = False
        self.takeoff_started = False
        self.takeoff_pos = np.zeros(3)
        self.landing = False
        self.land_started = False
        self.landing_pos = np.zeros(3)

        # Integral action settings
        self.delta_int = 0.001 # [ms]
        self.err_int = np.zeros(3)

        # self.take_off_trigger()
        # self.start_experiment_trigger()


    def evaluate_input(self, neigh_data):
        u = np.zeros(3)

        if self.current_pose.position is not None and self.current_pose.velocity is not None:
            print('gli agenti sono', N)
            if self.takeoff:
                if self.takeoff_started:
                    self.err_int = np.zeros(3)
                    self.takeoff_started = False
                    x_des, y_des, z_des = self.current_pose.position
                    self.takeoff_pos = np.array([x_des,y_des,z_des])

                if self.takeoff_pos[2] <= self.height:
                    self.takeoff_pos[2] += 1/self.update_frequency*0.2

                err_pos = self.current_pose.position - self.takeoff_pos
                err_vel = self.current_pose.velocity
                self.err_int += self.delta_int*err_pos

                # Sent only if is follower -> See self.send_input()
                u = - (self.prop_gain*err_pos + self.deriv_gain*err_vel + self.int_gain * self.err_int)

            elif self.landing:
                if self.land_started:
                    self.land_started = False
                    x_des, y_des, z_des = self.current_pose.position
                    self.landing_pos = np.array([x_des,y_des,z_des])
            
                if self.landing_pos[2] > 0.01:
                    self.landing_pos[2] -= 1/self.update_frequency*0.2

                err_pos = self.current_pose.position - self.landing_pos
                err_vel = self.current_pose.velocity
                self.err_int += self.delta_int*err_pos
                
                # Sent only if is follower -> See self.send_input()
                u = - (self.prop_gain*err_pos + self.deriv_gain*err_vel + self.int_gain * self.err_int)

            elif self.formation:
                i = self.id
                dd = self.dd
                N = self.N
                for j, neigh_pose in neigh_data.items():
                    err_pos = self.current_pose.position - neigh_pose.position

                    neigh_dist = self.distances[j]
                    # err_vel = self.current_pose.velocity - neigh_pose.velocity
                    self.err_int_bearinig += self.delta_int*err_pos

                    formation_d_potential = (np.linalg.norm(err_pos, ord=2)**2 - neigh_dist**2) * (err_pos)

                    u += formation_d_potential

        else:
            self.get_logger().warn('Pose or Velocity are None')

        return u




    def take_off_trigger(self):
        time.sleep(25)
        self.get_logger().info('takeoff wakeup')
        self.start_take_off(1)

    def start_experiment_trigger(self):
        time.sleep(40)
        self.get_logger().info('experiment wakeup')
        self.start_experiment(1)

    def start_experiment(self, _):
        self.get_logger().info('Starting experiment')
        self.landing = False
        self.takeoff = False
        self.formation = True

    def start_take_off(self, _):
        self.get_logger().info('Starting Take-Off')
        self.landing = False
        self.formation = False
        self.takeoff = True
        self.takeoff_started = True

    def start_land(self, _):
        self.get_logger().info('Starting Landing')
        self.takeoff = False
        self.formation = False
        self.landing = True
        self.land_started = True

    def send_input(self, u):
        msg = Vector3()

        msg.x = u[0]
        msg.y = u[1]
        msg.z = u[2]
        self.publisher_.publish(msg)