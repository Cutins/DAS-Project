^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package webots_ros2_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.3 (2022-05-30)
------------------
* Fixed support for Humble and Rolling.

1.2.0 (2021-12-21)
------------------
* Fix the controller_manager update rate.

1.1.3 (2021-11-05)
------------------
* Added build dependency on 'ros_environment'.

1.1.2 (2021-11-03)
------------------
* Added code compliance for 'ROS Foxy'.

1.1.0 (2021-07-19)
------------------
* Initial version
