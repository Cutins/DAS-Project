---
name: Documentation
about: Fix or improve the documentation

---

**Documentation page(s) concerned**
Link to the concerned page.

**What is the problem with the current documentation?**
A clear and concise description of what's wrong with the current documentation.

**Describe how you would fix it**
A clear and concise description of what need to be changed.
