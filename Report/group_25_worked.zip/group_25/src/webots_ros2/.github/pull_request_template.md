**Description**
Describe the bug you are fixing, the new feature your are introducing or the enhancement you are proposing.

**Related Issues**
This pull-request fixes issue #

**Affected Packages**
List of affected packages:
  - webots_ros2_A
  - webots_ros2_B

**Tasks**
Add the list of tasks of this PR.
  - [ ] Task 1
  - [ ] Task 2

**Additional context**
Add any other context about the pull-request here.
