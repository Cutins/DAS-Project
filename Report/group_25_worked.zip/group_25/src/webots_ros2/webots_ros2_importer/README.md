# URDF and Xacro Importers

This package allows URDF and Xacro robot models to be imported in Webots.

Please use the following links for more details:

* [Tutorial: Using URDF or Xacro](https://github.com/cyberbotics/webots_ros2/wiki/Using-URDF-or-Xacro)
