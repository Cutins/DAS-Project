^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package webots_ros2_importer
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.3 (2022-05-30)
------------------
* Upgraded to urdf2webots 1.0.18

1.1.0 (2021-07-19)
------------------
* Upgraded to urdf2webots 1.0.10

1.0.0 (2020-09-01)
------------------
* Added the '--multi-file', '--static-base', '--tool-slot' and '--rotation' arguments.

0.0.3 (2020-06-15)
------------------
* Initial version
