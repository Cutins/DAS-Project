# webots-libcontroller

> Notice: The library is automatically updated with the CI jobs running in [the main webots repository](https://github.com/cyberbotics/webots).
> Any change made in this repository will be automatically overridden by the CI jobs.

This repository contains the Webots controller library, compiled for Linux, macOS, and Windows.
It is primarily created to allow compilation of the [`webots_ros2`](https://github.com/cyberbotics/webots_ros2) interface without dependency on the complete Webots repository.
